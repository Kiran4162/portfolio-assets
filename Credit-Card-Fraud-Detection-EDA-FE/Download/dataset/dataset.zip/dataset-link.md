**In case you are unable to open the zip**



Dataset - https://www.kaggle.com/datasets/kartik2112/fraud-detection

